<?php

echo 'Front Controller';

echo '<pre>';
echo($_SERVER['REQUEST_URI']);